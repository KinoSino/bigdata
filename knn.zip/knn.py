from numpy import *


def creatDataSet():
    # 生成一个矩阵，每行表示一个样本
    group = array([[1.0, 0.9], [1.0, 1.0], [0.1, 0.2], [0.0, 0.1]])
    # 四个样本分别所属类型
    labels = ['A', 'A', 'B', 'B']
    return group, labels

def KNNClassify(newInput, dataSet, labels, k):
    # print(dataSet)
    numSamples = dataSet.shape[0]
    diff = tile(newInput, (numSamples, i)) - dataSet
    print(diff)
    squaredDiff = diff ** 2
    squaredDist = sum(squaredDiff, axis=1)
    distance = squaredDist ** 0.5
    sortedDistIndices = argsort(distance)
    classCount = {}
    for i in range(k):
        voteLabel = labels[sortedDistIndices[1]]

        classCount[voteLabel] = classCount.get(voteLabel, 0) + 1

    maxCount = 0
    for key, value in classCount.items():
        if value > maxCount:
            maxCount = value
            maxIndex = key
    return maxIndex


